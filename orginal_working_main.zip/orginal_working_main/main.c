/***********************************************************************************
 * FILE ID 		: Main.c
 * VERSION NUMBER 	: 1.0.0
 * PROJECT CODE 	: ITS04T
 * PROJECT NAME 	: Test FreeRTOS- for Universal Traffic Control System CUTE Adv
 * ARCHITECT            : Hemant
 * DESIGNER             :
 * AUTHOR 	     	: Hemant
 * DATE OFLAST UPDATION : 05.11.2022
 * DESCRIPTION 		:
************************************************************************************/

/* FreeRTOS kernel includes. */
#include <FreeRTOS.h>
#include <task.h>
/* thejas64 includes. */
#include "uart.h"

#include "gpio.h"
#include "led.h"
#include "stdlib.h"

#include "ads1015.h"
#include "i2c_api.h"
#include "adc.h"
#include "i2c.h"
#include "interrupt.h"
#include "spi.h"
#include "at25sf161.h"


////////////////////////////////////////////////////////////
/* Standard includes. */


#include <stdio.h>
#include <string.h>

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "semphr.h"

/* thejas64 incldues. */
#include "riscv_hal.h"

/* Standard demo application includes. */
#include "dynamic.h"
#include "blocktim.h"
#include "GenQTest.h"
#include "recmutex.h"
#include "TimerDemo.h"
#include "EventGroupsDemo.h"
#include "TaskNotify.h"
#include "AbortDelay.h"
#include "countsem.h"
#include "death.h"

#include "encoding.h"
/////////////////////////////////////////////////////////////////////////
#define mainCREATE_DEMO_ONLY	5
#define mainHART_0 		0
#define UART1_INTR_NUM 1


//Prototypes for the standard FreeRTOS callback/hook  https://www.freertos.org/a00016.html
void vApplicationMallocFailedHook (void);
void vApplicationIdleHook (void);
void vApplicationStackOverflowHook (TaskHandle_t pxTask, char *pcTaskName);
void vApplicationTickHook (void);

static void prvSetupHardware (void);	//Prepare haredware to run the demo.
/* Send a messaage to the UART initialised in prvSetupHardware. */

//void Init_uart(void);
void vSendString (const char *const pcString);
void Transmit_uart (UC*);

/*-----------------------------------------------------------*/
/* The UART to which strings are output, and the GPIO used to toggle the LED. */
//static UART_instance_t g_uart;
//static gpio_instance_t g_gpio_out;
/* Timer Porting for Thejas64 */
/*extern uint64_t ullNextTime;
 extern volatile uint64_t * pullMachineTimerCompareRegister ;*/

extern uint64_t ullNextTime;
extern volatile uint32_t *pullMachineTimerCompareRegister;
extern volatile uint32_t *pullMachineTimerCompareRegisterMSB;

extern const uint32_t uxTimerIncrementsForOneTick;

extern volatile int count;
extern volatile unsigned char test_value[100];
extern volatile int receive_com_flag;


/*void vPortSetupTimerInterrupttu (void)
{

  pullMachineTimerCompareRegister = (volatile uint32_t* const ) ( configMTIMECMP_BASE_ADDRESS);
  //uint64_t ulCurrentTime;
  //volatile uint64_t *const pulTime = (volatile uint64_t* const ) ( configCLINT_BASE_ADDRESS + 0x580);

  uint32_t ulCurrentTimeHigh, ulCurrentTimeLow;

  volatile uint32_t *const pulTimeHigh = (volatile uint32_t* const ) (( configMTIME_BASE_ADDRESS) + 4UL); //8-byte typer so high 32-bit word is 4 bytes up.
  volatile uint32_t *const pulTimeLow = (volatile uint32_t* const ) ( configMTIME_BASE_ADDRESS);

  volatile uint32_t *const pulTimeCmpHigh = (volatile uint32_t* const ) (( configMTIMECMP_BASE_ADDRESS) + 4UL); //8-byte typer so high 32-bit word is 4 bytes up.
  volatile uint32_t *const pulTimeCmpLow = (volatile uint32_t* const ) ( configMTIMECMP_BASE_ADDRESS);
  //pullMachineTimerCompareRegister = (volatile uint32_t*) ( configMTIMECMP_BASE_ADDRESS);
  // Prepare the time to use after the next tick interrupt.
  do{
      ulCurrentTimeHigh = *pulTimeHigh;
      ulCurrentTimeLow = *pulTimeLow;
  }  while (ulCurrentTimeHigh != *pulTimeHigh);
  ullNextTime = (uint64_t) ulCurrentTimeHigh;
  ullNextTime <<= 32ULL;  //High 4-byte word is 32-bits up.
  ullNextTime |= (uint64_t) ulCurrentTimeLow;
  //printf ("1 val of uxTimerIncrementsForOneTick %d, currentTime %ld\n", uxTimerIncrementsForOneTick, ullNextTime);
  ullNextTime += (uint64_t) uxTimerIncrementsForOneTick;
  *pulTimeCmpHigh=(uint32_t) (ullNextTime>>32ULL);
  *pulTimeCmpLow=(uint32_t) ullNextTime;
  ullNextTime += (uint64_t) uxTimerIncrementsForOneTick;
  // printf ("2 val of uxTimerIncrementsForOneTick %d, ullNextTime %ld\n", uxTimerIncrementsForOneTick, ullNextTime);
  //printf ("uint64_t %d\n", sizeof(uint64_t));
}*/
/*void vSendString( const char * const pcString )
 {
 Transmit_uart( (char *) pcString );
 }*/
/////////////////////////////////////////////////////////////////////////////
/*
extern uint32_t     __sdata_load;
extern uint32_t     __sdata_start;
extern uint32_t     __sdata_end;
extern uint32_t     __data_load;
extern uint32_t     __data_start;
extern uint32_t     __data_end;
extern uint32_t     __sbss_start;
extern uint32_t     __sbss_end;
extern uint32_t     __bss_start;
extern uint32_t     __bss_end;
extern uint32_t	    __stack_bottom;
extern uint32_t	    __stack_top;
*/
//static void prvCheckTask( void *pvParameters );
//Initialise and start the peripheral timers that are used to exercise external interrupt processing.
//static void prvSetupPeripheralTimers( void );

static void vgpiointTask( void *pvParameters );
//static void TestTask2( void *pvParameters );
//static void TestTask3( void *pvParameters );
extern void vSendString( const char * const pcString );
unsigned char task1_stat = 0, task2_stat = 0, task3_stat = 0;
extern void vToggleLED (void);

void uart_interrupt_receive (void);

//extern const StackType_t xISRStackTop;
#define mainCHECK_TASK_PRIORITY  (tskIDLE_PRIORITY+3)
/*-----------------------------------------------------------*/
//static QueueHandle_t xQueue = NULL;
/////////////////////////////////////////////////////////////////////////////

int main (void)
{
  prvSetupHardware();
  vSendString ("Thejas32 FreeRTOS Demo\n\r");
  //xQueue = xQueueCreate( mainQUEUE_LENGTH, sizeof( uint32_t ) );
  //main_full();
  /* Create the register check tasks, as described at the top of this	file.
  Use xTaskCreateStatic() to create a task using only statically allocated
  memory. */
  /*printf("__stack_bottom=%x\n\r",&__stack_bottom);
  printf("__stack_top=%x\n\r",&__stack_top);
  printf("__sdata_load=%x\n\r",&__sdata_load);
  printf("__sdata_start=%x\n\r",&__sdata_start);
  printf("__sdata_end=%x\n\r",&__sdata_end);

  printf("__data_load=%x\n\r",&__data_load);
  printf("__stack_top=%x\n\r",&__stack_top);
  printf("__stack_top=%x\n\r",&__stack_top);

  register int *stack_p asm ("sp");

  printf("stack_p=%x\n\r",stack_p);
  printf("*stack_p=%x\n\r",*stack_p);
  printf("xISRStackTop=%x",xISRStackTop);*/

  /* Start the reg test tasks which test the context switching mechanism. */
  /*xTaskCreate( prvRegTestTaskEntry1, "RegTst1", 1000, NULL, tskIDLE_PRIORITY, NULL );
  xTaskCreate( prvRegTestTaskEntry2, "RegTst2", 1000, NULL, tskIDLE_PRIORITY, NULL );*/

  //configMINIMAL_STACK_SIZE   , 1000
  //task_Name_Size of stack to allocate_Parameter ._Priority_handle
  /*xTaskCreate( TestTask1, "Reg1", configMINIMAL_STACK_SIZE, NULL, mainCHECK_TASK_PRIORITY, NULL );
  xTaskCreate( TestTask2, "Reg2", configMINIMAL_STACK_SIZE, NULL, mainCHECK_TASK_PRIORITY, NULL );
  xTaskCreate( TestTask3, "Reg3", configMINIMAL_STACK_SIZE, NULL, mainCHECK_TASK_PRIORITY, NULL );
*/


#if( mainCREATE_DEMO_ONLY == 0 )
    {
      main_full ();
    }

#elif( mainCREATE_DEMO_ONLY == 1 )
    {
      taskyield_demo ();
    }

#elif (mainCREATE_DEMO_ONLY == 2)
    {
      led_switch ();
    }

#elif (mainCREATE_DEMO_ONLY == 3)
    {

      gas_detector ();
    }
#elif (mainCREATE_DEMO_ONLY == 4)
    {

      gpio_interrupt ();
    }
#elif (mainCREATE_DEMO_ONLY == 5)
    {

      uart_interrupt_receive ();
    }
#else
    {

      main_blinky();
    }
#endif

}
/*-----------------------------------------------------------*/
//void uart1_intr_handler(void) {
//
//  //printf("in ISR");
//  unsigned char status, error, data;
//  	status = UartReg(UART_1).UART_IIR_FCR; // clearing interrupt
//  	data = UartReg(UART_1).UART_DR;//uart_getchar(UART_1, &error);   // reading data
//  	test_value[count] = data;
//  	//printf("address=%p\n\r",&test_value[count]);
//  	count++;
//
//  	if(count == 40)
//  	  {
//  	    count =0;
//  	    receive_com_flag = 1;
//  	  }
//
//  	//printf("%c\n\r", data);
//
//  	//printf("T.v = %p and R.C.P =  %p and count = %p\n\r",&test_value[0],&receive_com_flag, &count);
//  	//printf("data = %p\n\r", &data);
//
//  	//register void* sp __asm__("sp"); // Declare a register variable bound to `sp`
//       // printf("\n\rStack Pointer (sp) = %p\n", sp);
//
//
//        // register void* gp __asm__("gp"); // Declare a register variable bound to `gp`
//  	// printf("\n global Pointer (gp) = %p\n", gp);
//  	return;
//}

void uart1_intr_handler(void)
{
    static volatile int isr_counter = 0;
    isr_counter++;

    if (isr_counter % 100 == 0) {
        printf("ISR triggered %d times\n", isr_counter);
    }

    while (UartReg(UART_1).UART_LSR & 0x01) {
        uint8_t data = UartReg(UART_1).UART_DR;

        if (count < sizeof(test_value)) {
            test_value[count++] = data;
        }

        if (count >= 40) {
            count = 0;
            receive_com_flag = 1;
            UartReg(UART_1).UART_IE = 0x00;  // Disable RX interrupt
            break;
        }
    }
}





static void prvSetupHardware (void)
{
  //PLIC_init();
  //Init_uart();
  count =0;
  receive_com_flag = 0;
  interrupt_disable_all();
  disable_irq();

  uart_set_baud_rate(UART_1, 9600, 100000000); // initializing uart0
 // printf("+------[ uart%d in interrupt mode ]------+\n", UART_1);

  interrupt_enable(UART1_INTR_NUM); //Enable interrupt in controller.
  irq_register_handler(UART1_INTR_NUM, uart1_intr_handler);
  uart_intr_enable(UART_1, TX_DISABLE, RX_ENABLE); // enabling uart0 interrupt
  //printf("\nStart typing anything on uart%d.\n\n", UART_1);


 // GPIO_write_pin(25, 1);
  //GPIO_write_pin(20, 1);
  // ullNextTime = 0ULL;		// Used to program the machine timer compare register.
  //vSendString ("UART [OK]\n\r");
}
/*------------------------------------------------------------*/
static void vEepromTask( void *pvParameters )
{
   static TickType_t xNextWakeTime;
   //xNextWakeTime = xTaskGetTickCount();
   static uint8_t writeData[256], readData[512];
   int task1_time = 0;

       // Initialize the EEPROM
       	at25sf161Begin(MDP_SPI_3);
       	at25sf161ChipErase(); // Complete erase chip

       	// Read first 512 bytes
       	at25sf161ReadEeprom(readData, 512, 0x0);
       //	printf("\n at25sf161 read data :");
       	for (int i = 0; i < 512; i++)
       	{
       		if (i % 32 == 0)
       			printf("\n");
       		printf("%02x ", readData[i]);
       	}
       	printf("\n");

       	// Generate data for writing
       	for (int i = 0; i < 256; i++)
       	{
       		writeData[i] = i;
       	}

       	// Write data to EEPROM
       	at25sf161WriteEeprom(writeData, 256, 0x0);	 // Writing to Page 1
       	at25sf161WriteEeprom(writeData, 256, 0x100); // Writing to Page 2

       	// Read again
       	at25sf161ReadEeprom(readData, 512, 0x0);
       	printf("\n at25sf161 read data :");
       	for (int i = 0; i < 512; i++)
       	{
       		if (i % 32 == 0)
       			printf("\n");
       		printf("%02x ", readData[i]);
       	}
       	printf("\n");

       	// Erase first 64K block
       	at25sf161BlockErase(0x0, ERASE_64K);

       	// Task should not return
       	while (1)
       	{
       		vTaskDelay(pdMS_TO_TICKS(1000)); // Sleep for 1 second (prevents CPU blocking)
       	}


    vTaskDelete( NULL );
}


/*-----------------------------------------------------------*/
void vSendString (const char *const pcString)
{
    Transmit_uart ((char*) pcString);
}

/*-----------------------------------------------------------*/

void vApplicationMallocFailedHook (void)
{
  /* vApplicationMallocFailedHook() will only be called if
   configUSE_MALLOC_FAILED_HOOK is set to 1 in FreeRTOSConfig.h.  It is a hook
   function that will get called if a call to pvPortMalloc() fails.
   pvPortMalloc() is called internally by the kernel whenever a task, queue,
   timer or semaphore is created.  It is also called by various parts of the
   demo application.  If heap_1.c or heap_2.c are used, then the size of the
   heap available to pvPortMalloc() is defined by configTOTAL_HEAP_SIZE in
   FreeRTOSConfig.h, and the xPortGetFreeHeapSize() API function can be used
   to query the size of free heap space that remains (although it does not
   provide information on how the remaining heap might be fragmented). */
  vSendString ("@ ApplicationMallocFailedHook\n\r");
  taskDISABLE_INTERRUPTS();
  __asm volatile( "ebreak" );
  for (;;)
    ;
}
/*-----------------------------------------------------------*/

void vApplicationIdleHook (void)
{
  //vSendString("\r @ vApplicationIdleHook\n\r");
  /* vApplicationIdleHook() will only be called if configUSE_IDLE_HOOK is set
   to 1 in FreeRTOSConfig.h.  It will be called on each iteration of the idle
   task.  It is essential that code added to this hook function never attempts
   to block in any way (for example, call xQueueReceive() with a block time
   specified, or call vTaskDelay()).  If the application makes use of the
   vTaskDelete() API function (as this demo application does) then it is also
   important that vApplicationIdleHook() is permitted to return to its calling
   function, because it is the responsibility of the idle task to clean up
   memory allocated by the kernel to any task that has since been deleted. */
}
/*-----------------------------------------------------------*/

void
vApplicationStackOverflowHook (TaskHandle_t pxTask, char *pcTaskName)
{
  (void) pcTaskName;
  (void) pxTask;

  printf("stack overflow %x %s\r\n", pxTask, (portCHAR *)pcTaskName);
  vSendString ("@ vApplicationStackOverflowHook\n\r");
  //printf("taskname =%s\n\r",pcTaskName);
  /* Run time stack overflow checking is performed if
   configCHECK_FOR_STACK_OVERFLOW is defined to 1 or 2.  This hook
   function is called if a stack overflow is detected. */
  taskDISABLE_INTERRUPTS();
//  __asm volatile( "ebreak" );
  for (;;)
    ;
}
/*-----------------------------------------------------------*/

void
vApplicationTickHook (void)
{
  vSendString ("@ vApplicationTickHook\n\r");
  /* The tests in the full demo expect some interaction with interrupts. */
}






/*****
 * main_full() creates all the demo application tasks and software timers, then
 * starts the scheduler.  The web documentation provides more details of the
 * standard demo application tasks, which provide no particular functionality,
 * but do provide a good example of how to use the FreeRTOS API.
 *
 * In addition to the standard demo tasks, the following tasks and tests are
 * defined and/or created within this file:
 *
 * "Reg test" tasks - These fill both the core registers with known values, then
 * check that each register maintains its expected value for the lifetime of the
 * task.  Each task uses a different set of values.  The reg test tasks execute
 * with a very low priority, so get preempted very frequently.  A register
 * containing an unexpected value is indicative of an error in the context
 * switching mechanism.
 *
 * "Check" task - The check executes every three seconds.  It checks that all
 * the standard demo tasks, and the register check tasks, are not only still
 * executing, but are executing without reporting any errors.  If the check task
 * discovers that a task has either stalled, or reported an error, then it
 * prints an error message to the UART, otherwise it prints "Pass.".
 */

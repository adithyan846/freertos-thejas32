
/***********************************************************************************
 * FILE ID 		: Main.c
 * VERSION NUMBER 	: 1.0.0
 * PROJECT CODE 	: ITS04T
 * PROJECT NAME 	: Test FreeRTOS- for Universal Traffic Control System CUTE Adv
 * ARCHITECT            : Hemant
 * DESIGNER             :
 * AUTHOR 	     	: Hemant
 * DATE OFLAST UPDATION : 05.11.2022
 * DESCRIPTION 		:
 ************************************************************************************/

/* FreeRTOS kernel includes. */
// #include <FreeRTOS.h>
// #include <task.h>
/* thejas64 includes. */
#include "uart.h"

#include "gpio.h"
#include "led.h"
#include "stdlib.h"

#include "ads1015.h"
#include "i2c_api.h"
#include "adc.h"
#include "i2c.h"
#include "interrupt.h"
#include "spi.h"
#include "at25sf161.h"

////////////////////////////////////////////////////////////
/* Standard includes. */

#include <stdio.h>
#include <string.h>

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "semphr.h"

/* thejas64 incldues. */
#include "riscv_hal.h"

/* Standard demo application includes. */
#include "dynamic.h"
#include "blocktim.h"
#include "GenQTest.h"
#include "recmutex.h"
#include "TimerDemo.h"
#include "EventGroupsDemo.h"
#include "TaskNotify.h"
#include "AbortDelay.h"
#include "countsem.h"
#include "death.h"

#include "encoding.h"

#include <Includesapp/CommonDb.h>
#include "stdlib.h"
#include "Includesapp/main.h"
#include "pwmc.h"
// #include "i2c.h"
#include "config.h"
// #include "gpio.h"

/////////////////////////////////////////////////////////////////////////
#define mainCREATE_DEMO_ONLY 5
#define mainHART_0 0

#define I2C_FREQ 200000 // 200KHz   //400000  400KHz

#define ADDRESS_PCF1_LAMP1TO16 0x20
#define ADDRESS_PCF2_LAMP17TO32 0x22
#define ADDRESS_PCF3_LAMP33TO48 0x24
#define ADDRESS_PCF4_LAMP49TO64 0x26

#define ADDRESS_PCF1_FEEDBACK1TO16 0x21
#define ADDRESS_PCF2_FEEDBACK17TO32 0x23
#define ADDRESS_PCF3_FEEDBACK33TO48 0x25
#define ADDRESS_PCF4_FEEDBACK49TO64 0x27

#define GPIO_BASE_ADDR 0x10080000 // Replace with actual base address

#define GPIOI2CSW 15

// Prototypes for the standard FreeRTOS callback/hook  https://www.freertos.org/a00016.html
void vApplicationMallocFailedHook(void);
void vApplicationIdleHook(void);
void vApplicationStackOverflowHook(TaskHandle_t pxTask, char *pcTaskName);
void vApplicationTickHook(void);

static void prvSetupHardware(void); // Prepare haredware to run the demo.
/* Send a messaage to the UART initialised in prvSetupHardware. */

// void Init_uart(void);
void vSendString(const char *const pcString);
void Transmit_uart(UC *);

extern volatile unsigned char USART_Rx_Index, USART1_data_length, Uart_received_CompleteFlag;
extern volatile unsigned char status, error, data;

extern unsigned short LampSwitchDatapac[8];
extern unsigned char LampflashSelection;
extern unsigned char LDsense;
unsigned char LampflashSelectionswitchcount = 0, LampFeedbackPingEnableReadRdDne = 0;
unsigned short Lamppatterndummy = 0x0203;

extern unsigned char Save_Pattern_Flash, Junction_ID, Last_Uart_received_CompleteFlag;
extern unsigned char Lamp_switching_flag, Switch_Type_Flash, Ack_Lamp_Feedback_Flag, Rx_New_Pattern_Flag;

extern unsigned char currentSpi, LampFBReadFlag, StartFeedbackFlag;
extern US currentChipSelectGPIO;
extern unsigned short previousADCDATA, currentADCDATA, Last_Chk_LampStatus;

extern volatile int rx_flag, rx_count;

extern volatile unsigned char rx_buffer[100];
extern volatile unsigned char USART_Rx_IndexT, Uart_received_CompleteFlagT;

static void vgpiointTask(void *pvParameters);
static void vEepromTask(void *pvParameters);
// static void TestTask2( void *pvParameters );
// static void TestTask3( void *pvParameters );
extern void vSendString(const char *const pcString);
unsigned char task1_stat = 0, task2_stat = 0, task3_stat = 0;
extern void vToggleLED(void);
// extern const StackType_t xISRStackTop;
#define mainCHECK_TASK_PRIORITY (tskIDLE_PRIORITY + 3)

static void prvSetupHardware(void)
{
	// PLIC_init();
	// Init_uart();
	interrupt_disable_all();
	disable_irq();
	// GPIO_write_pin(25, 1);
	//  GPIO_write_pin(20, 1);
	//Initialization();
	// ullNextTime = 0ULL;		// Used to program the machine timer compare register.
	// GPIO_write_pin(GPIOI2CSW, LOW);

	uart_interrupt_receive_init();

	vSendString("UART [OK]\n\r");
}

/*------------------------------------------------------------*/

/*-----------------------------------------------------------*/
void vSendString(const char *const pcString)
{
	Transmit_uart((char *)pcString);
}

/*-----------------------------------------------------------*/

void vApplicationMallocFailedHook(void)
{
	/* vApplicationMallocFailedHook() will only be called if
	 configUSE_MALLOC_FAILED_HOOK is set to 1 in FreeRTOSConfig.h.  It is a hook
	 function that will get called if a call to pvPortMalloc() fails.
	 pvPortMalloc() is called internally by the kernel whenever a task, queue,
	 timer or semaphore is created.  It is also called by various parts of the
	 demo application.  If heap_1.c or heap_2.c are used, then the size of the
	 heap available to pvPortMalloc() is defined by configTOTAL_HEAP_SIZE in
	 FreeRTOSConfig.h, and the xPortGetFreeHeapSize() API function can be used
	 to query the size of free heap space that remains (although it does not
	 provide information on how the remaining heap might be fragmented). */
	vSendString("@ ApplicationMallocFailedHook\n\r");
	taskDISABLE_INTERRUPTS();
	__asm volatile("ebreak");
	for (;;)
		;
}
/*-----------------------------------------------------------*/

void vApplicationIdleHook(void)
{
	// vSendString("\r @ vApplicationIdleHook\n\r");
	/* vApplicationIdleHook() will only be called if configUSE_IDLE_HOOK is set
	 to 1 in FreeRTOSConfig.h.  It will be called on each iteration of the idle
	 task.  It is essential that code added to this hook function never attempts
	 to block in any way (for example, call xQueueReceive() with a block time
	 specified, or call vTaskDelay()).  If the application makes use of the
	 vTaskDelete() API function (as this demo application does) then it is also
	 important that vApplicationIdleHook() is permitted to return to its calling
	 function, because it is the responsibility of the idle task to clean up
	 memory allocated by the kernel to any task that has since been deleted. */
}
/*-----------------------------------------------------------*/

void vApplicationStackOverflowHook(TaskHandle_t pxTask, char *pcTaskName)
{
	(void)pcTaskName;
	(void)pxTask;

	printf("stack overflow %x %s\r\n", pxTask, (portCHAR *)pcTaskName);
	vSendString("@ vApplicationStackOverflowHook\n\r");
	// printf("taskname =%s\n\r",pcTaskName);
	/* Run time stack overflow checking is performed if
	 configCHECK_FOR_STACK_OVERFLOW is defined to 1 or 2.  This hook
	 function is called if a stack overflow is detected. */
	taskDISABLE_INTERRUPTS();
	//  __asm volatile( "ebreak" );
	for (;;)
		;
}
/*-----------------------------------------------------------*/

void vApplicationTickHook(void)
{
	vSendString("@ vApplicationTickHook\n\r");
	/* The tests in the full demo expect some interaction with interrupts. */
}

static void vEepromTask(void *pvParameters)
{
	// static TickType_t xNextWakeTime;
	// xNextWakeTime = xTaskGetTickCount();
	//  static uint8_t writeData[256], readData[512];
	int task1_time = 0;

	printf("\n\rIntensity setting");
	// pwmc_continuous_mode(PWM_CH_3,PWM_OPC_LOW,800000,100000); //8ms :1ms
	// pwmc_continuous_mode(PWM_CH_3,PWM_OPC_LOW,600000,150000); //6ms:1.5ms
	// pwmc_continuous_mode(PWM_CH_3,PWM_OPC_LOW,1200000,300000); //12ms:3ms
	//pwmc_continuous_mode(PWM_CH_3, PWM_OPC_LOW, 1200000, 1200000);
	printf("\n\r Malfunction management unit");
	printf("\n\rIntensity setting Completed");
	rx_flag = 0;
	rx_count = 0;

	USART_Rx_Index = 0;
	USART1_data_length = 0;
	Uart_received_CompleteFlag = 0;
	status = 0;
	error = 0;
	data = 0;
	Lamp_UART_SendFlag = 0;
	Save_Pattern_Flash = 0;
	Junction_ID = 1;
	Last_Uart_received_CompleteFlag = 0;
	Lamp_switching_flag = 0;
	Switch_Type_Flash = 0;
	Ack_Lamp_Feedback_Flag = 0;
	Rx_New_Pattern_Flag = 0;
	Last_halfsec_sw_flag = 0;
	Cnt_Delay_1ms = 0;
	multiWrite_rtn = 0;

	currentSpi = 0;
	LampFBReadFlag = 0;
	StartFeedbackFlag = 1;
	currentChipSelectGPIO = 0;
	previousADCDATA = 0;
	currentADCDATA = 0;
	Last_Chk_LampStatus = 0;

	LampSwitchDatapac[0] = 0xFFFF;
	usleep(2000000);
	LampSwitchDatapac[1] = 0xFFFF;
	LampSwitchDatapac[2] = 0xFFFF;
	LampSwitchDatapac[3] = 0xFFFF;

	// Task should not return
	while (1)
	{
		// vTaskDelay(pdMS_TO_TICKS(1000)); // Sleep for 1 second (prevents CPU blocking)
		//printf("application print");
		//register void *sp __asm__("sp"); // Declare a register variable bound to `sp`
		//printf("\n\rStack Pointer (sp) = %p\n", sp);

		vTaskDelay(1000);
		// Uart_received_CompleteFlagT = 1;
		// USART_Rx_IndexT = 8;

		SMARCRxUART_PacketValidation();
		// interrupt_enable(1);

		if ((LampFBReadFlag == 1) || (StartFeedbackFlag == 1))
		{
			//printf("\n\r test SPI ");
			// ReadStore_ADC7490_CurrentVal_LDC();
		}
		if (Lamp_UART_SendFlag == 1)
		{
			Lamp_UART_SendFlag = 0;
			Send_Acknowledgement_WithLampCurrent_ToSMARC();
			// usleep(1000);    //50000
			vTaskDelay(1);
		}
		if (CurrentReadingFlag == 1)
		{
			CurrentReadingFlag = 0;
			// Send_Acknowledgement_WithLampFeedback_ToSMARC ();
			Send_Acknowledgement_WithLampFBBytes_ToSMARC();
			// usleep(1000);   //100000
			vTaskDelay(1);
			if (halfsec_sw_flag == 1)
			{
				halfsec_sw_flag = 0;
				Lamp_UART_SendFlag = 1;
			}
			// Send_Acknowledgement_WithLampFBBytes_ToSMARC ();
			// usleep(20000);
		}
		if (Cnt_Delay_1ms >= 2400) // 1 min
		{
			Cnt_Delay_1ms = 0;
			halfsec_sw_flag = 1; // halfsec_sw_flag + 1;
			// printf("\n\r  N= %d", halfsec_sw_flag);
		}
		else
		{
			Cnt_Delay_1ms++;
			// printf("\n\r  Nx= %d", Cnt_Delay_1ms);
		}
		// usleep(105000);   //20000
		vTaskDelay(105);
		if (IntensityChangeFlag == 1)
		{
			printf("\n\rIntensity %d", intensitydata * 25);
			IntensityChangeFlag = 0;
			// pwmc_continuous_mode(PWM_CH_3,PWM_OPC_LOW,1200000,intensitydata * 300000);
			Send_IntensityChangeAck_ToSMARC();
		}

		if (LampFeedbackPingFlag == 1)
		{
			// if(LampFeedbackPingEnableReadRdDne == 1)
			//{
			LampFeedbackPingFlag = 0;
			Send_PingReplyFBEverySec_ToSMARC();
			//}
		}

		printf("\n\rLDC Write Start");

	}
}

int main(void)
{
	prvSetupHardware();
	vSendString("Thejas32 FreeRTOS Demo\n\r");

	if (xTaskCreate(vEepromTask, "Reg1", 300, NULL, 2, NULL))
	{
		vSendString("EEPROM_Task Created \n\r");
	}

	/* Start the scheduler. */
	vTaskStartScheduler();
	for (;;)
		;
}
